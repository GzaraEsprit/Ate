#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_rotozoom.h>
#include <time.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define TOTAL_PUZZLES 5
#define TOTAL_CHOICES 3

typedef struct {
    SDL_Surface* baseImage;
    SDL_Surface* shadowImage;
    SDL_Surface* choices[TOTAL_CHOICES];
    SDL_Rect choicePositions[TOTAL_CHOICES];
    SDL_Rect dropZone;
    int correctIndex;
} Puzzle;

typedef struct {
    int dragging;
    int draggedIndex;
    int offsetX, offsetY;
} DragState;

// Function declarations
void initSDL();
void loadResources();
void handleEvents(int* quitter, int* volume, int* fullscreen);
void render();
void cleanup();

void initPuzzle(Puzzle* p, int index);
void renderPuzzle(SDL_Surface* screen, Puzzle* p);
void renderTimer(SDL_Surface* screen, Uint32 startTime, Uint32 maxTime);
int checkDrop(Puzzle* p, int x, int y);
void renderSuccess(SDL_Surface* screen);
void renderFailure(SDL_Surface* screen);
void freePuzzle(Puzzle* p);

// Optional: declare external globals (only if needed across files)
// extern SDL_Surface* screen;
// extern Puzzle puzzles[TOTAL_PUZZLES];
// extern DragState drag;
// extern int currentPuzzle;
// extern Uint32 startTime;
// extern Uint32 maxTime;

#endif

