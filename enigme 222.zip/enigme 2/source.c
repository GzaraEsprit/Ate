#include "header.h"

// Global variables
SDL_Surface* screen;
SDL_Surface* background;  // Nouvelle surface pour le background
Puzzle puzzles[TOTAL_PUZZLES];
int currentPuzzle = 0;
DragState drag = {0, -1, 0, 0};
Uint32 startTime;
Uint32 maxTime = 15000;

void initSDL() {
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);
    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("Puzzle Game", NULL);
    srand(time(NULL));
   
    // Charger l'image de fond
    background = IMG_Load("assets/background.png");
    if (!background) {
        printf("Erreur de chargement du background: %s\n", IMG_GetError());
        // Créer un fond uni si l'image n'est pas trouvée
        background = SDL_CreateRGBSurface(SDL_SWSURFACE, SCREEN_WIDTH, SCREEN_HEIGHT, 32,
                                         0, 0, 0, 0);
        SDL_FillRect(background, NULL, SDL_MapRGB(background->format, 100, 149, 237)); // Couleur bleu clair
    }
}

void loadResources() {
    for (int i = 0; i < TOTAL_PUZZLES; i++) {
        initPuzzle(&puzzles[i], i);
    }
    startTime = SDL_GetTicks();
}

void handleEvents(int* quitter, int* volume, int* fullscreen) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) *quitter = 0;

        else if (event.type == SDL_MOUSEBUTTONDOWN) {
            for (int i = 0; i < TOTAL_CHOICES; i++) {
                SDL_Rect pos = puzzles[currentPuzzle].choicePositions[i];
                if (event.button.x >= pos.x && event.button.x <= pos.x + 100 &&
                    event.button.y >= pos.y && event.button.y <= pos.y + 100) {
                    drag.dragging = 1;
                    drag.draggedIndex = i;
                    drag.offsetX = event.button.x - pos.x;
                    drag.offsetY = event.button.y - pos.y;
                }
            }
        }

        else if (event.type == SDL_MOUSEMOTION && drag.dragging) {
            puzzles[currentPuzzle].choicePositions[drag.draggedIndex].x = event.motion.x - drag.offsetX;
            puzzles[currentPuzzle].choicePositions[drag.draggedIndex].y = event.motion.y - drag.offsetY;
        }

        else if (event.type == SDL_MOUSEBUTTONUP && drag.dragging) {
            int inZone = checkDrop(&puzzles[currentPuzzle], event.button.x, event.button.y);
            drag.dragging = 0;

            if (inZone) {
                if (drag.draggedIndex == puzzles[currentPuzzle].correctIndex) {
                    renderSuccess(screen);
                } else {
                    renderFailure(screen);
                }
                SDL_Flip(screen);
                SDL_Delay(1500);
                freePuzzle(&puzzles[currentPuzzle]);
                currentPuzzle++;
                startTime = SDL_GetTicks();
            }
        }
    }
}

void render() {
    // D'abord le background
    SDL_BlitSurface(background, NULL, screen, NULL);
   
    // Ensuite le reste
    if (currentPuzzle < TOTAL_PUZZLES) {
        renderPuzzle(screen, &puzzles[currentPuzzle]);
        renderTimer(screen, startTime, maxTime);

        if (SDL_GetTicks() - startTime >= maxTime) {
            renderFailure(screen);
            SDL_Flip(screen);
            SDL_Delay(1500);
            freePuzzle(&puzzles[currentPuzzle]);
            currentPuzzle++;
            startTime = SDL_GetTicks();
        }
    } else {
        SDL_Rect message = {SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 - 25, 200, 50};
        SDL_FillRect(screen, &message, SDL_MapRGB(screen->format, 255, 255, 255));
    }

    SDL_Flip(screen);
}

void cleanup() {
    // Libérer le background
    SDL_FreeSurface(background);
   
    for (int i = 0; i < TOTAL_PUZZLES; i++) {
        freePuzzle(&puzzles[i]);
    }
    SDL_Quit();
}

void initPuzzle(Puzzle* p, int index) {
    char path[100];

    sprintf(path, "assets/puzzle%d/base.png", index);
    p->baseImage = IMG_Load(path);

    sprintf(path, "assets/puzzle%d/shadow.png", index);
    p->shadowImage = IMG_Load(path);
   
    // Get shadow image dimensions
    SDL_Rect shadowRect;
    SDL_GetClipRect(p->shadowImage, &shadowRect);
   
    // Set drop zone to match shadow image position and size
    p->dropZone.x = 353;  // Position ajustée pour le nouveau layout
    p->dropZone.y = 190;  // Position ajustée pour le nouveau layout
    p->dropZone.w = shadowRect.w;
    p->dropZone.h = shadowRect.h;

    for (int i = 0; i < TOTAL_CHOICES; i++) {
        sprintf(path, "assets/puzzle%d/choice%d.png", index, i);
        p->choices[i] = IMG_Load(path);
        p->choicePositions[i].x = 100 + i * 200;
        p->choicePositions[i].y = 420;
    }

    p->correctIndex = rand() % TOTAL_CHOICES;
}

void renderPuzzle(SDL_Surface* screen, Puzzle* p) {
    // Le background est déjà affiché, on ajoute juste les éléments du puzzle
    SDL_BlitSurface(p->baseImage, NULL, screen, &(SDL_Rect){150,80,0,0});
    // The shadow image is blitted to the drop zone position
    SDL_BlitSurface(p->shadowImage, NULL, screen, &p->dropZone);
    for (int i = 0; i < TOTAL_CHOICES; i++) {
        SDL_BlitSurface(p->choices[i], NULL, screen, &p->choicePositions[i]);
    }
}

void renderTimer(SDL_Surface* screen, Uint32 startTime, Uint32 maxTime) {
    Uint32 now = SDL_GetTicks();
    float progress = 1.0f - (float)(now - startTime) / maxTime;
    if (progress < 0) progress = 0;

    int barWidth = SCREEN_WIDTH * progress;
    SDL_Rect bar = {0, 20, barWidth, 20};
    SDL_FillRect(screen, &bar, SDL_MapRGB(screen->format, 255, 153, 0));  // Orange
}

int checkDrop(Puzzle* p, int x, int y) {
    // Check if the drop position is within the shadow image area
    return (x >= p->dropZone.x && x <= p->dropZone.x + p->dropZone.w &&
            y >= p->dropZone.y && y <= p->dropZone.y + p->dropZone.h);
}

void renderSuccess(SDL_Surface* screen) {
    SDL_Surface* zoom = zoomSurface(screen, 1.1, 1.1, 1);
    SDL_BlitSurface(zoom, NULL, screen, NULL);
    SDL_FreeSurface(zoom);

    SDL_Rect rect = {SCREEN_WIDTH / 2 - 50, SCREEN_HEIGHT / 2 - 25, 100, 50};
    SDL_FillRect(screen, &rect, SDL_MapRGB(screen->format, 0, 255, 0));  // Green
}

void renderFailure(SDL_Surface* screen) {
    SDL_Surface* zoom = zoomSurface(screen, 0.9, 0.9, 1);
    SDL_BlitSurface(zoom, NULL, screen, NULL);
    SDL_FreeSurface(zoom);

    SDL_Rect rect = {SCREEN_WIDTH / 2 - 50, SCREEN_HEIGHT / 2 - 25, 100, 50};
    SDL_FillRect(screen, &rect, SDL_MapRGB(screen->format, 255, 0, 0));  // Red
}

void freePuzzle(Puzzle* p) {
    SDL_FreeSurface(p->baseImage);
    SDL_FreeSurface(p->shadowImage);
    for (int i = 0; i < TOTAL_CHOICES; i++) {
        SDL_FreeSurface(p->choices[i]);
    }
}
