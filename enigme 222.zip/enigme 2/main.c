#include "header.h"

int main() {
    int quitter = 1;
    int volume = 50;
    int fullscreen = 0;

    initSDL();
    loadResources();

    while (quitter) {
        handleEvents(&quitter, &volume, &fullscreen);
        render();
    }

    cleanup();
    return 0;
}
