#include "header.h"

// Global variables
SDL_Surface* screen;
SDL_Surface* background;
SDL_Surface* victoryImage;
SDL_Surface* defeatImage;   
Puzzle puzzles[TOTAL_PUZZLES];
int currentPuzzle = 0;
DragState drag = {0, -1, 0, 0};
Uint32 startTime;
Uint32 maxTime = 15000;

void initSDL() {
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);
    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("Puzzle Game", NULL);
    srand(time(NULL));
   
    // Charger les images
    background = IMG_Load("assets/background.png");
    victoryImage = IMG_Load("assets/victory.png");
    defeatImage = IMG_Load("assets/defeat.png");
    
    if (!background) {
        printf("Erreur de chargement du background: %s\n", IMG_GetError());
        background = SDL_CreateRGBSurface(SDL_SWSURFACE, SCREEN_WIDTH, SCREEN_HEIGHT, 32,
                                         0, 0, 0, 0);
        SDL_FillRect(background, NULL, SDL_MapRGB(background->format, 100, 149, 237));
    }
    
    if (!victoryImage) {
        printf("Warning: Impossible de charger victory.png\n");
        // Créer une image de remplacement
        victoryImage = SDL_CreateRGBSurface(SDL_SWSURFACE, 200, 100, 32, 0, 0, 0, 0);
        SDL_FillRect(victoryImage, NULL, SDL_MapRGB(victoryImage->format, 0, 255, 0));
    }
    
    if (!defeatImage) {
        printf("Warning: Impossible de charger defeat.png\n");
        // Créer une image de remplacement
        defeatImage = SDL_CreateRGBSurface(SDL_SWSURFACE, 200, 100, 32, 0, 0, 0, 0);
        SDL_FillRect(defeatImage, NULL, SDL_MapRGB(defeatImage->format, 255, 0, 0));
    }
}

void loadResources() {
    // Initialiser tous les puzzles
    for (int i = 0; i < TOTAL_PUZZLES; i++) {
        initPuzzle(&puzzles[i], i);
    }
    
    // Mélanger l'ordre des puzzles
    for (int i = TOTAL_PUZZLES - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        Puzzle temp = puzzles[i];
        puzzles[i] = puzzles[j];
        puzzles[j] = temp;
    }
    
    startTime = SDL_GetTicks();
    currentPuzzle = 0;  // Commencer par le premier puzzle du tableau mélangé
int remaining = TOTAL_PUZZLES;
while (remaining > 0) {
    int j = rand() % remaining;
    Puzzle temp = puzzles[remaining-1];
    puzzles[remaining-1] = puzzles[j];
    puzzles[j] = temp;
    remaining--;
}

}
void handleEvents(int* quitter, int* volume, int* fullscreen){
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            *quitter = 1;
        }
        else if (event.type == SDL_MOUSEBUTTONDOWN) {
            // Gestion du drag (identique à votre version originale)
            for (int i = 0; i < TOTAL_CHOICES; i++) {
                SDL_Rect pos = puzzles[currentPuzzle].choicePositions[i];
                if (event.button.x >= pos.x && event.button.x <= pos.x + 100 &&
                    event.button.y >= pos.y && event.button.y <= pos.y + 100) {
                    drag.dragging = 1;
                    drag.draggedIndex = i;
                    drag.offsetX = event.button.x - pos.x;
                    drag.offsetY = event.button.y - pos.y;
                }
            }
        }
        else if (event.type == SDL_MOUSEMOTION && drag.dragging) {
            puzzles[currentPuzzle].choicePositions[drag.draggedIndex].x = event.motion.x - drag.offsetX;
            puzzles[currentPuzzle].choicePositions[drag.draggedIndex].y = event.motion.y - drag.offsetY;
        }
        else if (event.type == SDL_MOUSEBUTTONUP && drag.dragging) {
            int inZone = checkDrop(&puzzles[currentPuzzle], event.button.x, event.button.y);
            drag.dragging = 0;

            if (inZone) {
                Uint32 animationStart = SDL_GetTicks();
                int isCorrect = (drag.draggedIndex == puzzles[currentPuzzle].correctIndex);
                
                // Boucle d'animation
                while (SDL_GetTicks() - animationStart < 1500) {
                    // Réaffiche le puzzle de base
                    SDL_BlitSurface(background, NULL, screen, NULL);
                    renderPuzzle(screen, &puzzles[currentPuzzle]);
                    
                    // Superpose l'animation
                    if (isCorrect) {
                        renderSuccess(screen);
                    } else {
                        renderFailure(screen);
                    }
                    
                    SDL_Flip(screen);
                    SDL_Delay(16); // ~60 FPS
                }

                // Gestion après animation
                freePuzzle(&puzzles[currentPuzzle]);
                currentPuzzle++;
                
                if (currentPuzzle < TOTAL_PUZZLES) {
                    startTime = SDL_GetTicks(); // Reset timer pour le prochain puzzle
		        } else {
	    // Tous les puzzles sont terminés - Victoire !
	    Uint32 endTime = SDL_GetTicks();
	    while (SDL_GetTicks() - endTime < 3000) {
		renderSuccess(screen);
		SDL_Flip(screen);
		SDL_Delay(16);
	    }
	    *quitter = 1;
	}
            }
        }
    }
}

void render() {
    // D'abord le background
    SDL_BlitSurface(background, NULL, screen, NULL);
   
    // Ensuite le reste
    if (currentPuzzle < TOTAL_PUZZLES) {
        renderPuzzle(screen, &puzzles[currentPuzzle]);
        renderTimer(screen, startTime, maxTime);

    if (SDL_GetTicks() - startTime >= maxTime) {
    Uint32 animStart = SDL_GetTicks();
    while (SDL_GetTicks() - animStart < 1500) {
        SDL_BlitSurface(background, NULL, screen, NULL);
        renderPuzzle(screen, &puzzles[currentPuzzle]);
        renderFailure(screen);
        SDL_Flip(screen);
        SDL_Delay(16);
    }
    freePuzzle(&puzzles[currentPuzzle]);
    currentPuzzle++;
    if (currentPuzzle < TOTAL_PUZZLES) {
        startTime = SDL_GetTicks();
    } else {
        currentPuzzle = TOTAL_PUZZLES;
    }
}
    } else {
        SDL_Rect message = {SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 - 25, 200, 50};
        SDL_FillRect(screen, &message, SDL_MapRGB(screen->format, 255, 255, 255));
    }

    SDL_Flip(screen);
}

void cleanup() {
    SDL_FreeSurface(background);
    SDL_FreeSurface(victoryImage);
    SDL_FreeSurface(defeatImage);
   
    for (int i = 0; i < TOTAL_PUZZLES; i++) {
        freePuzzle(&puzzles[i]);
    }
   
    IMG_Quit();
    SDL_Quit();
}
void initPuzzle(Puzzle* p, int index) {
    char path[100];
    p->played = 0; 

    sprintf(path, "assets/puzzle%d/base.png", index);
    p->baseImage = IMG_Load(path);

    sprintf(path, "assets/puzzle%d/shadow.png", index);
    p->shadowImage = IMG_Load(path);
   
    // Get shadow image dimensions
    SDL_Rect shadowRect;
    SDL_GetClipRect(p->shadowImage, &shadowRect);
   
    // Définir des positions différentes selon le puzzle
    if (index == 1) { // Puzzle 2 (index 1)
        p->dropZone.x = 318;
        p->dropZone.y = 278;
    }
    else if (index == 2) { // Nouvelle condition pour Puzzle 3 (index 2)
        p->dropZone.x = 335;  // Exemple: 400
        p->dropZone.y = 420;  // Exemple: 220
    }
    else if (index == 3) { // Nouvelle condition pour Puzzle 3 (index 2)
        p->dropZone.x = 507;  // Exemple: 400
        p->dropZone.y = 335;  // Exemple: 220
    }
    else if (index == 4) { // Nouvelle condition pour Puzzle 3 (index 2)
        p->dropZone.x = 305;  // Exemple: 400
        p->dropZone.y = 335;  // Exemple: 220
    }
    else { // Position par défaut pour les autres puzzles (Puzzle 1, etc.)
        p->dropZone.x = 353;
        p->dropZone.y = 190;
    }
   
    p->dropZone.w = shadowRect.w;
    p->dropZone.h = shadowRect.h;

    for (int i = 0; i < TOTAL_CHOICES; i++) {
        sprintf(path, "assets/puzzle%d/choice%d.png", index, i);
        p->choices[i] = IMG_Load(path);
       
        // Position personnalisée pour chaque choix du puzzle 2
        if (index == 2) { // Puzzle 2
            switch (i) {
                case 0: // Choix 1
                    p->choicePositions[i].x = 45;
                    p->choicePositions[i].y = 50;
                    break;
                case 1: // Choix 2
                    p->choicePositions[i].x = 45;
                    p->choicePositions[i].y = 180;
                    break;
                case 2: // Choix 3
                    p->choicePositions[i].x = 45;
                    p->choicePositions[i].y = 270;
                    break;
                case 3: // Choix 4
                    p->choicePositions[i].x = 500;
                    p->choicePositions[i].y = 450;
                    break;
                // Ajoutez plus de cas si TOTAL_CHOICES > 4
                default:
                    p->choicePositions[i].x = 100 + i * 200;
                    p->choicePositions[i].y = 420;
            }
        } else {
            // Position par défaut pour les autres puzzles
            p->choicePositions[i].x = 100 + i * 200;
            p->choicePositions[i].y = 420;
        }
    }

    p->correctIndex = 0;
}
void renderPuzzle(SDL_Surface* screen, Puzzle* p) {
    // Le background est déjà affiché, on ajoute juste les éléments du puzzle
    SDL_BlitSurface(p->baseImage, NULL, screen, &(SDL_Rect){150,80,0,0});
    // The shadow image is blitted to the drop zone position
    SDL_BlitSurface(p->shadowImage, NULL, screen, &p->dropZone);
    for (int i = 0; i < TOTAL_CHOICES; i++) {
        SDL_BlitSurface(p->choices[i], NULL, screen, &p->choicePositions[i]);
    }
}

void renderTimer(SDL_Surface* screen, Uint32 startTime, Uint32 maxTime) {
    Uint32 now = SDL_GetTicks();
    float progress = 1.0f - (float)(now - startTime) / maxTime;
    if (progress < 0) progress = 0;

    int barWidth = SCREEN_WIDTH * progress;
    SDL_Rect bar = {0, 20, barWidth, 20};
    SDL_FillRect(screen, &bar, SDL_MapRGB(screen->format, 255, 153, 0));  // Orange
}

int checkDrop(Puzzle* p, int x, int y) {
    // Check if the drop position is within the shadow image area
    return (x >= p->dropZone.x && x <= p->dropZone.x + p->dropZone.w &&
            y >= p->dropZone.y && y <= p->dropZone.y + p->dropZone.h);
}

void renderSuccess(SDL_Surface* screen) {
    // Effet de zoom pulsé
    float zoom = 1.0f + 0.2f * sin(SDL_GetTicks() * 0.01f);
    SDL_Surface* zoomed = rotozoomSurface(victoryImage, 0, zoom, 1);
    
    SDL_Rect dstrect = {
        (screen->w - zoomed->w) / 2,
        (screen->h - zoomed->h) / 2,
        0, 0
    };
    
    // Dessiner un rectangle semi-transparent directement
    SDL_Rect overlay = {0, 0, screen->w, screen->h};
    boxRGBA(screen, overlay.x, overlay.y, overlay.x + overlay.w, overlay.y + overlay.h,
           0, 0, 0, 128); // Noir semi-transparent (alpha = 128)
    
    // Afficher l'image zoomée
    SDL_BlitSurface(zoomed, NULL, screen, &dstrect);
    SDL_FreeSurface(zoomed);
}

void renderFailure(SDL_Surface* screen) {
    // Vérification que l'image existe
    if (!defeatImage) {
        // Fallback si l'image n'est pas chargée
        SDL_Rect rect = {SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 - 50, 200, 100};
        SDL_FillRect(screen, &rect, SDL_MapRGB(screen->format, 150, 0, 0));
        stringColor(screen, SCREEN_WIDTH/2 - 30, SCREEN_HEIGHT/2 - 10, "ECHEC!", 
                   SDL_MapRGB(screen->format, 255, 255, 255));
        return;
    }

    // Tremblement plus prononcé
    int shake_x = (rand() % 20) - 10; // -10 à +10
    int shake_y = (rand() % 20) - 10;
    
    // Position avec tremblement
    SDL_Rect dstrect = {
        (screen->w - defeatImage->w)/2 + shake_x,
        (screen->h - defeatImage->h)/2 + shake_y,
        defeatImage->w,
        defeatImage->h
    };
    
    // Fond semi-transparent (plus visible)
    SDL_Surface* overlay = SDL_CreateRGBSurface(SDL_SWSURFACE, screen->w, screen->h, 32,
                                              0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
    SDL_FillRect(overlay, NULL, SDL_MapRGBA(overlay->format, 100, 0, 0, 128));
    SDL_BlitSurface(overlay, NULL, screen, NULL);
    SDL_FreeSurface(overlay);
    
    // Affichage de l'image de défaite
    SDL_BlitSurface(defeatImage, NULL, screen, &dstrect);
}

void freePuzzle(Puzzle* p) {
    SDL_FreeSurface(p->baseImage);
    SDL_FreeSurface(p->shadowImage);
    for (int i = 0; i < TOTAL_CHOICES; i++) {
        SDL_FreeSurface(p->choices[i]);
    }
}
