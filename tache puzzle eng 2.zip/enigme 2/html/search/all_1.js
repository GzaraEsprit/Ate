var searchData=
[
  ['puzzle',['Puzzle',['../structPuzzle.html',1,'']]]
];
