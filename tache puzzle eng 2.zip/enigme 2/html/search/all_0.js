var searchData=
[
  ['dragstate',['DragState',['../structDragState.html',1,'']]]
];
