var indexSectionsWithContent =
{
  0: "dp",
  1: "dp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures"
};

